package com.example.task_service;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/tasks")
public class TaskController {

    @GetMapping
    public String getTasks() {
        return "List of tasks";
    }

    @PostMapping
    public String createTask() {
        return "Task created";
    }
}
